<?php 
if(isset($_POST['submit'])){

    $amount = $_POST['amount'];

    $test_amount = $amount*100;
}
require 'vendor/autoload.php';

// Set your secret key. Remember to switch to your live secret key in production.
// See your keys here: https://dashboard.stripe.com/apikeys
\Stripe\Stripe::setApiKey('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');

header('Content-Type: application/json');

$YOUR_DOMAIN = 'http://localhost/stripe/stripe-checkout.php';

try {
  $checkout_session = \Stripe\Checkout\Session::create([    
    'line_items' => [[
      'price_data' => [
        'currency' => 'gbp',
        'product_data' => [
          'name' => 'Amount',
        ],
        'unit_amount' => $test_amount,
      ],
      'quantity' => 1,
    ]],   
    'mode' => 'payment',
    'success_url' => 'http://localhost/stripe/success.php?session_id={CHECKOUT_SESSION_ID}',
    'cancel_url' => 'http://localhost/stripe/cancel.php',
  ]);

  header("HTTP/1.1 303 See Other");
  header("Location: " . $checkout_session->url);
  $_SESSION['cart'] = $checkout_session->customer;
} catch (Error $e) {
  http_response_code(500);
  echo json_encode(['error' => $e->getMessage()]);
}


?>