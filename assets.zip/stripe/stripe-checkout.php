<html>
  <head>
    <!-- bootstrap css  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
    <title>Construction Helps</title>
  </head>
  <body>

    <div class="container mt-5">
      <div class="card">
        <div class="card-header">
          <center><img src="https://constructionhelps.com/images/construction/construction_logo.svg" width="205px" alt="Construction Helps Logo"></center>
        </div>
        <div class="card-body">
          <div class="row justify-content-center">
            <div class="form-group">
                <div class="col-md-3" style="margin-left: 61vh;">
                  <h3 style="text-align: center;">Online Payment</h3> <hr>
                  <form action="payment.php" method="POST" autocomplete="off">
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text">£</span>
                      </div>
                      <input type="text" name="amount" placeholder="Amount" class="form-control">
                    </div>
                    <center>
                    <button class="btn btn-primary mt-3" type="submit" name="submit">Proceed</button>
                    </center>
                  </form>
                </div>
            </div>
          </div>
        </div>
        <div class="card-footer">
          <center>
            <h6>
              <a href="stripe-checkout.php">New Payment</a>
            </h6>
          </center>
        </div>
      </div>      
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
  </body>
</html>