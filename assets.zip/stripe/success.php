<?php 
require 'vendor/autoload.php';

\Stripe\Stripe::setApiKey('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');
$session_id = $_GET['session_id'];
$session = \Stripe\Checkout\Session::retrieve($session_id);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Successfull Transaction | ConstructionHelps</title>
    <!-- bootstrap css  -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css">
</head>
<body>
    
    <center>
        <h3>Your Transaction Has Been Successful</h3>
        <h4>Your Payment Transaction Id: <?php echo $session['payment_intent'] ?></h4>
        <h6>
        <a href="stripe-checkout.php">Back to Payment</a>
    </h6>
    </center>
    

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>